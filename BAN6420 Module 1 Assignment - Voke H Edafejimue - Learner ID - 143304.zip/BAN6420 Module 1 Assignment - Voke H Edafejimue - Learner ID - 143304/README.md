#BAN6420 Module 1 Assignment
#Voke Harrison Edafejimue
#Learner ID - 143304

#Highridge Construction Company Payment Slips
#Print payslips for each Employee
#Display name, salary, gender and employee level
#June 2024

Attached are 2 Scripts written in Python and R, for creating a dynamic data structures that collect and store upto 400 Employee info from users. Employee info include: Full Name, Gender and Salary. 
This information is used to print payslips for each Employee. While collecting this data, the user is asked if they would like to enter a new record. 
If the user enters 'Y', then they can proceed to enter more records to a maximum of 400 employees Or Choose 'N'. 
If the user enters 'N', then they are asked if they would like to print Payslips for the data entered. 
If they enter 'Y', then payslips are generated for all the employees who's data has been entered. 
If the user enters 'N' then the program stops. Also, Error handling is included in both the Python and R scripts.